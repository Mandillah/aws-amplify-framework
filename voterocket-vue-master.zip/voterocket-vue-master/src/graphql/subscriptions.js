// eslint-disable
// this is an auto generated file. This will be overwritten

export const onCastVote = `subscription OnCastVote {
  onCastVote {
    id
    name
    description
    votes
  }
}
`;
export const onCreateCandidate = `subscription OnCreateCandidate {
  onCreateCandidate {
    id
    name
    description
    votes
  }
}
`;
export const onUpdateCandidate = `subscription OnUpdateCandidate {
  onUpdateCandidate {
    id
    name
    description
    votes
  }
}
`;
export const onDeleteCandidate = `subscription OnDeleteCandidate {
  onDeleteCandidate {
    id
    name
    description
    votes
  }
}
`;
