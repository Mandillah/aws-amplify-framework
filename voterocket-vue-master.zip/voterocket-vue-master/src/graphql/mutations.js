// eslint-disable
// this is an auto generated file. This will be overwritten

export const castVote = `mutation CastVote($input: CastVoteInput!) {
  castVote(input: $input) {
    id
    name
    description
    votes
  }
}
`;
export const createCandidate = `mutation CreateCandidate($input: CreateCandidateInput!) {
  createCandidate(input: $input) {
    id
    name
    description
    votes
  }
}
`;
export const updateCandidate = `mutation UpdateCandidate($input: UpdateCandidateInput!) {
  updateCandidate(input: $input) {
    id
    name
    description
    votes
  }
}
`;
export const deleteCandidate = `mutation DeleteCandidate($input: DeleteCandidateInput!) {
  deleteCandidate(input: $input) {
    id
    name
    description
    votes
  }
}
`;
